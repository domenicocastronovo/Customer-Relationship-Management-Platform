from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class Customer(models.Model):
    user = models.OneToOneField(User, null=True, blank=True, on_delete=models.CASCADE)
    customer_id = models.CharField(max_length=200, null=True)
    credit_limit = models.CharField(max_length=200, null=True)
    name = models.CharField(max_length=200, null=True)
    phone = models.CharField(max_length=200, null=True)
    ar = models.FloatField(max_length=200, null=True)
    customer_country = models.CharField(max_length=200, null=True)
    email = models.CharField(max_length=200, null=True)
    past_due = models.FloatField(max_length=200, null=True)
    past_due_hor = models.FloatField(max_length=200, null=True)


    def __str__(self):
        return self.name


class Invoice(models.Model):
    STATUS = (
            ('Past Due', 'Past Due'),
            ('Regular', 'Regular'),
            ('Paid', 'Paid'),
            )
    customer = models.ForeignKey(Customer, null=True, on_delete=models.SET_NULL)
    invoice_num = models.CharField(max_length=200, null=True)
    status = models.CharField(max_length=200, null=True, choices=STATUS)
    due_date = models.DateTimeField(null=True)
    document_date = models.DateTimeField(null=True)
    ptp = models.CharField(max_length=200, null=True)
    amount = models.FloatField(max_length=200, null=True)


    def __str__(self):
        return self.customer.name
