from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.forms import UserCreationForm


from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import Group
from django.db.models import Sum


# Create your views here.
from .models import *
from .forms import InvoiceForm, CreateUserForm, CustomerForm
from .filters import InvoiceFilter
from .decorators import unauthenticated_user, allowed_users, admin_only


@unauthenticated_user
def registerPage(request):
    form = CreateUserForm()
    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')

            group = Group.objects.get(name='customer')
            user.groups.add(group)
            #Added username after video because of error returning customer name if not added
            Customer.objects.create(user=user,
            name=user.username,
            )

            messages.success(request, 'Account was created for ' + username)

            return redirect('login')

    context = {'form':form}
    return render(request, 'accounts/register.html', context)


@unauthenticated_user
def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password =request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('home')
        else:
            messages.info(request, 'Username OR password is incorrect')

    context = {}
    return render(request, 'accounts/login.html', context)


def logoutUser(request):
    logout(request)
    return redirect('login')






@login_required(login_url='login')
@admin_only
def home(request):
    customers = Customer.objects.all()
    total_customers = customers.count()
    total_ar = Customer.objects.aggregate(Sum('ar'))
    total_pd  = Customer.objects.aggregate(Sum('past_due'))
    total_pd_hor = Customer.objects.aggregate(Sum('past_due_hor'))


    context = {'customers': customers, 'total_customers': total_customers, 'total_ar':total_ar, 'total_pd':total_pd, 'total_pd_hor':total_pd_hor}

    return render(request, 'accounts/dashboard.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['admin'])
def customer(request, pk_test):
    customer = Customer.objects.get(id=pk_test)

    invoices = customer.invoice_set.all()
    invoice_count = invoices.count()

    myFilter = InvoiceFilter(request.GET, queryset=invoices)
    invoices = myFilter.qs

    context = {'customer': customer, 'invoices': invoices, 'invoice_count': invoice_count, 'myFilter':myFilter}
    return render(request, 'accounts/customer.html', context)


@login_required(login_url='login')
@allowed_users(allowed_roles=['customer'])
def userPage(request):
    invoices = request.user.customer.invoice_set.all()

    total_invoices = invoices.count()

    customer_phone = request.user.customer.phone
    customer_ar = request.user.customer.ar

    print('INVOICES:', invoices)

    context = {'invoices': invoices, 'total_invoices': total_invoices, 'customer_phone': customer_phone, 'customer_ar':customer_ar}
    return render(request, 'accounts/user.html', context)





@login_required(login_url='login')
@allowed_users(allowed_roles=['customer'])
def accountSettings(request):
    customer = request.user.customer
    form = CustomerForm(instance=customer)
    if request.method == 'POST':
        form = CustomerForm(request.POST, request.FILES,instance=customer)
        if form.is_valid():
            form.save()
    context = {'form':form}
    return render(request, 'accounts/account_settings.html', context)





@login_required(login_url='login')
@allowed_users(allowed_roles=['customer'])
def updateStatus(request, pk):
    invoice = Invoice.objects.get(id=pk)
    form = InvoiceForm(instance=invoice)

    if request.method == 'POST':
        #print('Priting POST:', request.POST)
        form = InvoiceForm(request.POST, instance=invoice)
        if form.is_valid():
            form.save()
            return redirect('/')

    context = {'form':form}
    return render(request, 'accounts/status_change.html', context)
