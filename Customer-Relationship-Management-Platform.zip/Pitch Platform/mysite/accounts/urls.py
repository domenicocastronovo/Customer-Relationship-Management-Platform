from django.urls import path
from . import views


urlpatterns = [
    path('', views.home, name='home'),
    path('customer/<str:pk_test>/', views.customer, name='customer'),
    path('user/', views.userPage, name='user-page'),

    path('update_status/<str:pk>/', views.updateStatus, name='update_status'),
    path('account/', views.accountSettings, name="account"),

    path('register/', views.registerPage, name="register"),
    path('login/', views.loginPage, name="login"),
    path('logout/', views.logoutUser, name="logout"),

]
